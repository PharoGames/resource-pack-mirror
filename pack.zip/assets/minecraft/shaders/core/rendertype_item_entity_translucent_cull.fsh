#version 330

// PharoGames override of the vanilla 1.21.11 program. Byte-identical to the shipped file except
// for one added const and the two render-distance fog arguments on the final line.
//
// WHY. The arena border is six packet ITEM_DISPLAY entities per viewer (plugin-border
// BorderRenderer), and its geometry reaches thousands of blocks: a HungerGames-event wall is 2500
// blocks wide and 664 tall. Vanilla's render-distance fog term is
// linear_fog_value(cylindricalVertexDistance, FogRenderDistanceStart, FogRenderDistanceEnd) with
// End = getEffectiveRenderDistance() * 16 and Start = End - clamp(End / 10, 4, 64). With
// server view-distance 12 that is 172.8 -> 192 blocks for every client, and apply_fog mixes only
// RGB while leaving alpha alone, so past 192 blocks the wall paints the horizon sky colour at its
// own 38 percent texture alpha. Because the metric is cylindrical, a vertical wall crosses the
// isosurface along two vertical world lines, which project to an exactly straight screen seam:
// purple on one side, sky on the other, over a 19-block ramp that reads as instant.
//
// WHAT THIS DOES. The fade now starts where vanilla's finishes and runs out to three times the
// render distance, so the wall keeps its colour to the old cutoff and then dissolves over a long
// gradient instead of stopping dead.
//
// WHY IT IS SAFE FOR EVERYTHING ELSE ON THIS PIPELINE (dropped items, item frames, held items,
// experience orbs, translucent block items, GUI items):
//   * The new band lies entirely beyond vanilla's, so the fog value is pointwise no greater than
//     before for every fragment. Nothing anywhere can become MORE fogged; the only possible effect
//     is that something distant stays visible.
//   * Everything else drawn here is a real entity, so the server only sends it inside the entity
//     tracking range (128 blocks at most), which is already inside vanilla's fog start. Those
//     fragments render exactly as they do today.
//   * The GUI binds a zeroed Fog UBO, so FogColor.a is 0 and apply_fog is an identity there under
//     both versions. This is the difference from the 2026-06-15 attempt, which branched on vertex
//     distance and fired on inventory items, whose Position is in GUI pixel space.
// The + 1.0 keeps end greater than start when FogRenderDistanceEnd is 0.
//
// Tune PG_FOG_REACH to change how far the border holds colour. Revert by deleting this file and
// republishing the pack. Re-verify against vanilla on every Minecraft upgrade: core-shader
// overrides are not a supported resource-pack feature and Mojang reworked this pipeline at
// 1.21.2, 1.21.5 and 1.21.6.

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;
in vec2 texCoord1;

out vec4 fragColor;

const float PG_FOG_REACH = 3.0;

void main() {
    vec4 color = texture(Sampler0, texCoord0) * vertexColor * ColorModulator;
    if (color.a < 0.1) {
        discard;
    }
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceEnd, FogRenderDistanceEnd * PG_FOG_REACH + 1.0, FogColor);
}
